function comments(state = [], action) {
  console.log(state, action);
  return state;
}

export default comments;
