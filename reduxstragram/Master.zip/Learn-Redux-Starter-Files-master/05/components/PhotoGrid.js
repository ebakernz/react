import React from 'react';

const PhotoGrid = React.createClass({
  render() {
    return (
      <div className="photo-grid">
      I'm the photo grid
      </div>
    )
  }
});

export default PhotoGrid;
