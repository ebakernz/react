import React from 'react';

const Single = React.createClass({
  render() {
    return (
      <div className="single-photo">
      Im the single
      </div>
    )
  }
});

export default Single;
